﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Vehicle : MonoBehaviour {

    //Movement Vectors 
    public Vector3 position;
    public Vector3 direction;
    public Vector3 velocity;
    public Vector3 acceleration;

    //Target to seek/flee
    private GameObject target;

    //Camera properties
    public Camera cam;
    public float minWidth;
    public float maxWidth;
    public float minHeight;
    public float maxHeight;

    //Forces to be applied
    public Vector3 wind;            //northeast wind
    public Vector3 gravity;         //not really gravity

    //Float Scalars
    public float mass;
    public float coeff;             //Coeff of friction
    public float maxSpeed;
    public float maxForce;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        CalcSteeringForces();
		
	}

    void ApplyForce(Vector3 force)
    {
        //F=MA so A=F/M
        //the "+=" allows forces to accumulate, without it eaach new force overwrites the old one

        acceleration += force / mass;
    }

    void ApplyFriction(float coeff)
    {
        Vector3 friction = velocity * -1;
        friction.Normalize();
        friction = friction * coeff;
        acceleration += friction;
    }

    //Seek a Location
    public Vector3 Seek(Vector3 targetLocation)
    {
        //Step 1: Calculate Desired Velocity
        //Vector from "myself" to my target
        Vector3 desiredVelocity = targetLocation - transform.position;

        //Step 2: Shrink DV to max speed (Clamping magnitude)
        //desiredVelocity = Vector3.ClampMagnitude(desiredVelocity, maxSpeed);

        //Another way of "setting magnitude" of DV
        //Normalize it then multiply by maxSpeed
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        //Step 3: calculate seek force
        //SF = DV - CV
        Vector3 seekForce = desiredVelocity - velocity;

        //Step 4: Apply seek force
        //ApplyForce(seekForce);

        return seekForce;

    }

    //Seek a GameObject
    public void Seek(GameObject target)
    {
        Seek(target.transform.position); 

    }



    //Flee from Location 
    public Vector3 Flee(Vector3 targetLocation)
    {
        //Step 1: Calculate Desired Velocity
        //Vector from "myself" to my target
        Vector3 desiredVelocity = targetLocation - transform.position;
        desiredVelocity *= -1;

        //Step 2: Shrink DV to max speed (Clamping magnitude)
        //desiredVelocity = Vector3.ClampMagnitude(desiredVelocity, maxSpeed);

        //Another way of "setting magnitude" of DV
        //Normalize it then multiply by maxSpeed
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        //Step 3: calculate seek force
        //SF = DV - CV
        Vector3 fleeForce = desiredVelocity - velocity;

        //Step 4: Apply seek force
        //ApplyForce(fleeForce);

        return fleeForce;
    }

    //Flee from GameObject
    public void Flee(GameObject target)
    {
        Flee(target.transform.position);
    }

    public abstract void CalcSteeringForces();

}
